package top.naccl.service;

import top.naccl.entity.CityVisitor;

public interface CityVisitorService {
	void saveCityVisitor(CityVisitor cityVisitor);
}
