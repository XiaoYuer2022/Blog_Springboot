package top.naccl.service;

import top.naccl.entity.VisitRecord;

public interface VisitRecordService {
	void saveVisitRecord(VisitRecord visitRecord);
}
