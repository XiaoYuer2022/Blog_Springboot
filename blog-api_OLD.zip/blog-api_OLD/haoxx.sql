-- MySQL dump 10.13  Distrib 8.0.33, for Linux (x86_64)
--
-- Host: localhost    Database: nblog
-- ------------------------------------------------------
-- Server version	8.0.33-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `about`
--

DROP TABLE IF EXISTS `about`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `about` (
  `id` bigint NOT NULL,
  `name_en` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `name_zh` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `about`
--

LOCK TABLES `about` WRITE;
/*!40000 ALTER TABLE `about` DISABLE KEYS */;
INSERT INTO `about` VALUES (1,'title','标题','关于帅气的 HaoXX'),(2,'musicId','网易云歌曲ID','423015580'),(3,'content','正文Markdown','哈哈哈'),(4,'commentEnabled','评论开关','true');
/*!40000 ALTER TABLE `about` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog`
--

DROP TABLE IF EXISTS `blog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blog` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '文章标题',
  `first_picture` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '文章首图，用于随机文章展示',
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '文章正文',
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '描述',
  `is_published` bit(1) NOT NULL COMMENT '公开或私密',
  `is_recommend` bit(1) NOT NULL COMMENT '推荐开关',
  `is_appreciation` bit(1) NOT NULL COMMENT '赞赏开关',
  `is_comment_enabled` bit(1) NOT NULL COMMENT '评论开关',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `update_time` datetime NOT NULL COMMENT '更新时间',
  `views` int NOT NULL COMMENT '浏览次数',
  `words` int NOT NULL COMMENT '文章字数',
  `read_time` int NOT NULL COMMENT '阅读时长(分钟)',
  `category_id` bigint NOT NULL COMMENT '文章分类',
  `is_top` bit(1) NOT NULL COMMENT '是否置顶',
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '密码保护',
  `user_id` bigint DEFAULT NULL COMMENT '文章作者',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `type_id` (`category_id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog`
--

LOCK TABLES `blog` WRITE;
/*!40000 ALTER TABLE `blog` DISABLE KEYS */;
INSERT INTO `blog` VALUES (1,'终端美化记录','https://tenapi.cn/v2/acg','## 一、ubuntu安装zsh、powerlevel10k\n\n参考[csdn的教程](https://blog.51cto.com/sddai/3030120)：\n\n[ohmyzsh的github](https://github.com/ohmyzsh/ohmyzsh)\n\n[powerlevel10k的github](https://github.com/romkatv/powerlevel10k)\n\npowerline这个不需要安装（powerlevel10k就是基于powerline的）：\n\n[powerline的github](https://github.com/powerline/powerline)\n\n1、安装zsh\n\n```bash\nsudo apt-get install zsh\n```\n2、安装oh-my-zsh\n```bash\n# 或者去仓库手动下载，然后运行install.sh\nsh -c \"$(curl -fsSL https://raw.github.com/robbyrussell/oh-my-zsh/master/tools/install.sh)\"\n```\n3、安装自动跳转插件和语法高亮插件、语法历史记录插件\n\n说明：zsh插件的位置在`/root/.oh-my-zsh//plugins`目录下。\n\n```bash\nsudo apt-get install autojump\n# 配置教程：cat /usr/share/doc/autojump/README.Debian\nvim .zshrc\n#在最后一行加入，注意点后面是一个空格\n. /usr/share/autojump/autojump.sh\nsource ~/.zshrc\n```\n语法高亮：\n```bash\n> git clone https://github.com/zsh-users/zsh-syntax-highlighting.git\n> echo \"source ${(q-)PWD}/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh\" >> ${ZDOTDIR:-$HOME}/.zshrc\n> source ~/.zshrc\n```\nzsh-autosuggestions语法历史记录插件：\n```bash\n> git clone git://github.com/zsh-users/zsh-autosuggestions $ZSH_CUSTOM/plugins/zsh-autosuggestions\n> plugins=(zsh-autosuggestions)\n```\n\n4、安装powerlevel10k命令行显示主题：\n\n```bash\n# 1） 安装Meslo字体\n## 1.1）下载字体\nhttps://github.com/ryanoasis/nerd-fonts/tree/master/patched-fonts/Meslo/M/Regular\n## 1.2）安装字体\n# 将*.ttf字体文件放在/usr/share/fonts/custom目录下，该目录是自己新建的，然后\ncd /usr/share/fonts/agave\nsudo mkfontscale # 生成核心字体信息\nsudo mkfontdir # 生成字体文件夹\nsudo fc-cache -fv # 刷新系统字体缓存\n# 2）安装powerlevel10k\n## 2.1）下载\ngit clone --depth=1 https://gitee.com/romkatv/powerlevel10k.git ${ZSH_CUSTOM:-$HOME/.oh-my-zsh/custom}/themes/powerlevel10k\n## 2.2）安装\nSet ZSH_THEME=\"powerlevel10k/powerlevel10k\" in ~/.zshrc.\n## 说明：或者手动从github上下载powerlebel10k，然后放在/root/.oh-my-zsh/custom/themes目录下，最后在.zshrc中设置主题即可\n```\n\n### 1.1 powerlevel10k的配置\n\n见github仓库。  另外，您参考[CSDN的教程:powerlevel10k 颜色和图标的自定义设置](https://blog.csdn.net/qq_36835255/article/details/128101588)\n\n## 二、windows的powershell安装oh-my-posh\n\n1、查看官网：[oh-my-posh](https://ohmyposh.dev/)\n\n如果官网打不开的话就直接百度搜：oh my posh\n\n按照教程一步一步来：\n```powershell\n# 0、安装MesloLGMNerdFontXXX.ttf字体(三个字体)在windows设置中安装\nhttps://github.com/ryanoasis/nerd-fonts/tree/master/patched-fonts/Meslo/M/Regular\n# 1、安装oh-my-posh\nwinget install JanDeDobbeleer.OhMyPosh -s winget\n# 2、更新\nwinget upgrade JanDeDobbeleer.OhMyPosh -s winget\n# 3、查看当前终端名\noh-my-posh get shell\n# 4、打开配置文件\n## 4.1 查看配置文件是否存在：\nTest-Path $profile\n## 4.2 若不存在，就查看默认的配置文件路径：\necho $profile\n## 4.3 然后手动创建该路径和对应的配置文件\n# windowsPowerShell配置文件：C:\\Users\\50850\\Documents\\WindowsPowerShell\\Microsoft.PowerShell_profile.ps1\n# PowerShell配置文件：C:\\Users\\50850\\Documents\\PowerShell\\Microsoft.PowerShell_profile.ps1\n# 5、在配置文件中写入：\noh-my-posh init pwsh --config \"C:\\Users\\50850\\Documents\\WindowsPowerShell\\jandedobbeleer.omp.json\" | Invoke-Expression\n## 5.1 说明该json文件原路径是在：C:\\Users\\50850\\AppData\\Local\\Programs\\oh-my-posh\\themes\n## 5.2 请移动到自定义的位置，在更改\n# 6、重启powershell，配置完成\n# 7、补充，在vscode的powershell中的设置\n#参考：https://blog.csdn.net/dietime1943/article/details/122968934\n\n```\n### 2.1 oh-my-posh的配置\n\n参考文档：[CSDN的教程](https://blog.csdn.net/qq_36835255/article/details/128101588)\n\n\n2、自定义设置\n\n主要是对这个json文件进行修改，相关键名和参数值请参考官网。就当前配置而言，重点是更改blocks里面的东西。主要分为三块，由三个大括号包裹。type和alignment是配置提示符在终端的位置，newline选项相当于换行。\n\n然后的话，重点就在于segments数组的设置了：\n```markdown\n\"segments\": [\n        {\n          \"background\": \"#101010\",\n          \"foreground\": \"#ffffff\",\n          \"leading_diamond\": \"\\ue0b6\",\n          \"trailing_diamond\": \"\\ue0b4\",\n          \"style\": \"diamond\",\n          \"template\": \"\\uf007 {{ .UserName }}\",\n          \"type\": \"session\"\n        },\n        {\n        ...\n        }\n]\n```\n上述代码块是其中的一部分，他是设置了提示符中“用户名”相关的设置。1）前景颜色、背景颜色，当类型为`\"style\"=\"diamond\"`时，可以设置前后的字符，2）然后template键值里设置了用户名的值和表示形式。3）最后，有关字符的代码，可以查看网站：[nerdfonts](https://www.nerdfonts.com/cheat-sheet)。\n\n\n## 三、ubuntu安装lunar_vim插件管理器\n\n参考官网：[lunarvim](https://www.lunarvim.org/docs/installation) ，我感觉有点麻烦。\n\n\n\n\n## 四、vim插件安装和配置\n\n使用的是程序员卡尔的配置[程序员卡尔的github仓库](https://github.com/youngyangyang04/PowerVim)\n\n\n# 五、tmux的学习记录\n\n正在计划中...\n- [x] 完善tmux终端管理器的学习笔记','记录了Ubuntu下的VIM编辑器美化、zsh和bash终端美化，还有windows系统下的powershell美化',_binary '',_binary '',_binary '\0',_binary '','2023-05-14 14:00:14','2023-05-14 14:00:14',0,100,1,1,_binary '','',1);
/*!40000 ALTER TABLE `blog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_tag`
--

DROP TABLE IF EXISTS `blog_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blog_tag` (
  `blog_id` bigint NOT NULL,
  `tag_id` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_tag`
--

LOCK TABLES `blog_tag` WRITE;
/*!40000 ALTER TABLE `blog_tag` DISABLE KEYS */;
INSERT INTO `blog_tag` VALUES (1,1);
/*!40000 ALTER TABLE `blog_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'系统美化记录');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `city_visitor`
--

DROP TABLE IF EXISTS `city_visitor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `city_visitor` (
  `city` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '城市名称',
  `uv` int NOT NULL COMMENT '独立访客数量',
  PRIMARY KEY (`city`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `city_visitor`
--

LOCK TABLES `city_visitor` WRITE;
/*!40000 ALTER TABLE `city_visitor` DISABLE KEYS */;
/*!40000 ALTER TABLE `city_visitor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nickname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '昵称',
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '邮箱',
  `content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '评论内容',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '头像(图片路径)',
  `create_time` datetime DEFAULT NULL COMMENT '评论时间',
  `ip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '评论者ip地址',
  `is_published` bit(1) NOT NULL COMMENT '公开或回收站',
  `is_admin_comment` bit(1) NOT NULL COMMENT '博主回复',
  `page` int NOT NULL COMMENT '0普通文章，1关于我页面，2友链页面',
  `is_notice` bit(1) NOT NULL COMMENT '接收邮件提醒',
  `blog_id` bigint DEFAULT NULL COMMENT '所属的文章',
  `parent_comment_id` bigint NOT NULL COMMENT '父评论id，-1为根评论',
  `website` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '个人网站',
  `qq` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '如果评论昵称为QQ号，则将昵称和头像置为QQ昵称和QQ头像，并将此字段置为QQ号备份',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (1,'小鱼儿','508506630@qq.com','@[tv_白眼]哈哈哈','http://localhost:8090/image/2ba31285-ba33-442f-a2d7-2d82d0879063.jpeg','2023-05-14 13:49:23','10.16.11.187',_binary '',_binary '\0',1,_binary '',NULL,-1,'','508506630'),(2,'小鱼儿','508506630@qq.com','是的','http://localhost:8090/image/2ba31285-ba33-442f-a2d7-2d82d0879063.jpeg','2023-05-14 14:43:42','10.16.11.187',_binary '',_binary '\0',1,_binary '',NULL,1,'','508506630');
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exception_log`
--

DROP TABLE IF EXISTS `exception_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `exception_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `uri` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '请求接口',
  `method` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '请求方式',
  `param` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '请求参数',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '操作描述',
  `error` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT '异常信息',
  `ip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'ip',
  `ip_source` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'ip来源',
  `os` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '操作系统',
  `browser` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '浏览器',
  `create_time` datetime NOT NULL COMMENT '操作时间',
  `user_agent` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'user-agent用户代理',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exception_log`
--

LOCK TABLES `exception_log` WRITE;
/*!40000 ALTER TABLE `exception_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `exception_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `friend`
--

DROP TABLE IF EXISTS `friend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `friend` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nickname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '昵称',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '描述',
  `website` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '站点',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '头像',
  `is_published` bit(1) NOT NULL COMMENT '公开或隐藏',
  `views` int NOT NULL COMMENT '点击次数',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `friend`
--

LOCK TABLES `friend` WRITE;
/*!40000 ALTER TABLE `friend` DISABLE KEYS */;
/*!40000 ALTER TABLE `friend` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_log`
--

DROP TABLE IF EXISTS `login_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户名称',
  `ip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'ip',
  `ip_source` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'ip来源',
  `os` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '操作系统',
  `browser` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '浏览器',
  `status` bit(1) DEFAULT NULL COMMENT '登录状态',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '操作描述',
  `create_time` datetime NOT NULL COMMENT '登录时间',
  `user_agent` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'user-agent用户代理',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_log`
--

LOCK TABLES `login_log` WRITE;
/*!40000 ALTER TABLE `login_log` DISABLE KEYS */;
INSERT INTO `login_log` VALUES (1,'root','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',_binary '\0','用户名或密码错误','2023-05-14 11:18:04','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(2,'root','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',_binary '\0','用户名或密码错误','2023-05-14 11:19:07','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(3,'root','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',_binary '\0','用户名或密码错误','2023-05-14 11:28:25','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(4,'root','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',_binary '\0','用户名或密码错误','2023-05-14 11:41:10','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(5,'lili','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',_binary '\0','用户名或密码错误','2023-05-14 11:41:16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(6,'root','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',_binary '\0','用户名或密码错误','2023-05-14 11:41:21','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(7,'Admin','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',_binary '\0','用户名或密码错误','2023-05-14 11:45:59','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(8,'Admin','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',_binary '\0','用户名或密码错误','2023-05-14 11:46:01','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(9,'Admin','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',_binary '\0','用户名或密码错误','2023-05-14 11:46:02','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(10,'Admin','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',_binary '\0','用户名或密码错误','2023-05-14 12:33:31','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(11,'Admin','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',_binary '\0','用户名或密码错误','2023-05-14 12:33:38','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(12,'yuhao','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',_binary '\0','用户名或密码错误','2023-05-14 12:44:25','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(13,'Admin','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',_binary '\0','用户名或密码错误','2023-05-14 12:44:41','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(14,'Admin','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',_binary '\0','用户名或密码错误','2023-05-14 12:45:22','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(15,'Admin','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',_binary '\0','用户名或密码错误','2023-05-14 12:53:28','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(16,'Admin','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',_binary '','登录成功','2023-05-14 13:46:18','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(17,'haoxx','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',_binary '','登录成功','2023-05-14 13:54:28','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(18,'haoxx','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',_binary '','登录成功','2023-05-14 14:44:58','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(19,'haoxx','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',_binary '','登录成功','2023-05-14 14:46:53','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68');
/*!40000 ALTER TABLE `login_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `moment`
--

DROP TABLE IF EXISTS `moment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `moment` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '动态内容',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `likes` int DEFAULT NULL COMMENT '点赞数量',
  `is_published` bit(1) NOT NULL COMMENT '是否公开',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `moment`
--

LOCK TABLES `moment` WRITE;
/*!40000 ALTER TABLE `moment` DISABLE KEYS */;
INSERT INTO `moment` VALUES (1,'一个测试动态','2023-05-14 13:49:54',0,_binary '');
/*!40000 ALTER TABLE `moment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `operation_log`
--

DROP TABLE IF EXISTS `operation_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `operation_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '操作者用户名',
  `uri` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '请求接口',
  `method` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '请求方式',
  `param` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '请求参数',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '操作描述',
  `ip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'ip',
  `ip_source` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'ip来源',
  `os` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '操作系统',
  `browser` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '浏览器',
  `times` int NOT NULL COMMENT '请求耗时（毫秒）',
  `create_time` datetime NOT NULL COMMENT '操作时间',
  `user_agent` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'user-agent用户代理',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operation_log`
--

LOCK TABLES `operation_log` WRITE;
/*!40000 ALTER TABLE `operation_log` DISABLE KEYS */;
INSERT INTO `operation_log` VALUES (1,'Admin','/admin/siteSettings','POST','{\"map\":{\"settings\":[{\"id\":1,\"nameEn\":\"blogName\",\"nameZh\":\"博客名称\",\"value\":\"HaoXX\'s Blog\",\"type\":1},{\"id\":2,\"nameEn\":\"webTitleSuffix\",\"nameZh\":\"网页标题后缀\",\"value\":\" - HaoXX\'s Blog\",\"type\":1},{\"id\":3,\"nameEn\":\"footerImgTitle\",\"nameZh\":\"页脚图片标题\",\"value\":\"手机看本站\",\"type\":1},{\"id\":4,\"nameEn\":\"footerImgUrl\",\"nameZh\":\"页脚图片路径\",\"value\":\"/img/qr.png\",\"type\":1},{\"id\":5,\"nameEn\":\"copyright\",\"nameZh\":\"Copyright\",\"value\":\"{\\\"title\\\":\\\"Copyright © 2019 - 2022\\\",\\\"siteName\\\":\\\"HaoXX\'S BLOG\\\"}\",\"type\":1},{\"id\":6,\"nameEn\":\"beian\",\"nameZh\":\"ICP备案号\",\"value\":\"渝ICP备2023001651号\",\"type\":1},{\"id\":7,\"nameEn\":\"reward\",\"nameZh\":\"赞赏码\",\"value\":\"/img/reward.jpg\",\"type\":1},{\"id\":8,\"nameEn\":\"commentAdminFlag\",\"nameZh\":\"博主评论标识\",\"value\":\"咕咕\",\"type\":1},{\"id\":9,\"nameEn\":\"playlistServer\",\"nameZh\":\"播放器平台\",\"value\":\"netease\",\"type\":1},{\"id\":10,\"nameEn\":\"playlistId\",\"nameZh\":\"播放器歌单\",\"value\":\"3071528549\",\"type\":1},{\"id\":11,\"nameEn\":\"avatar\",\"nameZh\":\"头像\",\"value\":\"/img/avatar.jpg\",\"type\":2},{\"id\":12,\"nameEn\":\"name\",\"nameZh\":\"昵称\",\"value\":\"浩XX\",\"type\":2},{\"id\":13,\"nameEn\":\"rollText\",\"nameZh\":\"滚动个签\",\"value\":\"\\\"云鹤当归天，天不迎我妙木仙；\\\",\\\"游龙当归海，海不迎我自来也。\\\"\",\"type\":2},{\"id\":14,\"nameEn\":\"github\",\"nameZh\":\"GitHub\",\"value\":\"https://github.com/Naccl\",\"type\":2},{\"id\":15,\"nameEn\":\"telegram\",\"nameZh\":\"Telegram\",\"value\":\"https://t.me/NacclOfficial\",\"type\":2},{\"id\":16,\"nameEn\":\"qq\",\"nameZh\":\"QQ\",\"value\":\"http://sighttp.qq.com/authd?IDKEY=\",\"type\":2},{\"id\":17,\"nameEn\":\"bilibili\",\"nameZh\":\"bilibili\",\"value\":\"https://space.bilibili.com/\",\"type\":2},{\"id\":18,\"nameEn\":\"netease\",\"nameZh\":\"网易云音乐\",\"value\":\"https://music.163.com/#/user/home?id=\",\"type\":2},{\"id\":19,\"nameEn\":\"email\",\"nameZh\":\"email\",\"value\":\"mailto:you@example.com\",\"type\":2},{\"id\":20,\"nameEn\":\"favorite\",\"nameZh\":\"自定义\",\"value\":\"{\\\"title\\\":\\\"最喜欢的动漫 📺\\\",\\\"content\\\":\\\"异度侵入、春物语、NO GAME NO LIFE、实力至上主义的教室、辉夜大小姐、青春猪头少年不会梦到兔女郎学姐、路人女主、Re0、魔禁、超炮、俺妹、在下坂本、散华礼弥、OVERLORD、慎勇、人渣的本愿、白色相簿2、死亡笔记、DARLING in the FRANXX、鬼灭之刃\\\"}\",\"type\":2},{\"id\":21,\"nameEn\":\"favorite\",\"nameZh\":\"自定义\",\"value\":\"{\\\"title\\\":\\\"最','更新站点配置信息','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',51,'2023-05-14 13:47:56','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(2,'Admin','/admin/moment','POST','{\"moment\":{\"id\":1,\"content\":\"一个测试动态\",\"createTime\":1684043394000,\"likes\":0,\"published\":true}}','发布动态','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',11,'2023-05-14 13:49:57','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(3,'Admin','/admin/comment','PUT','{\"comment\":{\"id\":1,\"nickname\":\"小鱼儿\",\"email\":\"508506630@qq.com\",\"content\":\"@[tv_白眼]哈哈哈\",\"avatar\":\"http://localhost:8090/image/2ba31285-ba33-442f-a2d7-2d82d0879063.jpeg\",\"createTime\":null,\"website\":\"\",\"ip\":\"10.16.11.187\",\"published\":null,\"adminComment\":null,\"page\":null,\"notice\":null,\"parentCommentId\":null,\"qq\":null,\"blog\":null,\"replyComments\":[]}}','修改评论','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',3,'2023-05-14 13:50:19','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(4,'Admin','/admin/siteSettings','POST','{\"map\":{\"settings\":[{\"id\":1,\"nameEn\":\"blogName\",\"nameZh\":\"博客名称\",\"value\":\"Haoxxl\'s Blog\",\"type\":1},{\"id\":2,\"nameEn\":\"webTitleSuffix\",\"nameZh\":\"网页标题后缀\",\"value\":\" - Haoxx\'s Blog\",\"type\":1},{\"id\":3,\"nameEn\":\"footerImgTitle\",\"nameZh\":\"页脚图片标题\",\"value\":\"手机看本站\",\"type\":1},{\"id\":4,\"nameEn\":\"footerImgUrl\",\"nameZh\":\"页脚图片路径\",\"value\":\"/img/qr.png\",\"type\":1},{\"id\":5,\"nameEn\":\"copyright\",\"nameZh\":\"Copyright\",\"value\":\"{\\\"title\\\":\\\"Copyright © 2022 - 2023\\\",\\\"siteName\\\":\\\"HAOXX\'S BLOG\\\"}\",\"type\":1},{\"id\":6,\"nameEn\":\"beian\",\"nameZh\":\"ICP备案号\",\"value\":\"渝ICP备2023001651号\",\"type\":1},{\"id\":7,\"nameEn\":\"reward\",\"nameZh\":\"赞赏码\",\"value\":\"/img/reward.jpg\",\"type\":1},{\"id\":8,\"nameEn\":\"commentAdminFlag\",\"nameZh\":\"博主评论标识\",\"value\":\"小鱼\",\"type\":1},{\"id\":9,\"nameEn\":\"playlistServer\",\"nameZh\":\"播放器平台\",\"value\":\"netease\",\"type\":1},{\"id\":10,\"nameEn\":\"playlistId\",\"nameZh\":\"播放器歌单\",\"value\":\"3071528549\",\"type\":1},{\"id\":11,\"nameEn\":\"avatar\",\"nameZh\":\"头像\",\"value\":\"/img/avatar.jpg\",\"type\":2},{\"id\":12,\"nameEn\":\"name\",\"nameZh\":\"昵称\",\"value\":\"浩XX\",\"type\":2},{\"id\":13,\"nameEn\":\"rollText\",\"nameZh\":\"滚动个签\",\"value\":\"\\\"云鹤当归天，天不迎我妙木仙；\\\",\\\"游龙当归海，海不迎我自来也。\\\"\",\"type\":2},{\"id\":14,\"nameEn\":\"github\",\"nameZh\":\"GitHub\",\"value\":\"https://github.com/XiaoYuer2022\",\"type\":2},{\"id\":15,\"nameEn\":\"telegram\",\"nameZh\":\"Telegram\",\"value\":\"https://t.me/NacclOfficial\",\"type\":2},{\"id\":16,\"nameEn\":\"qq\",\"nameZh\":\"QQ\",\"value\":\"http://sighttp.qq.com/authd?IDKEY=\",\"type\":2},{\"id\":17,\"nameEn\":\"bilibili\",\"nameZh\":\"bilibili\",\"value\":\"https://space.bilibili.com/\",\"type\":2},{\"id\":18,\"nameEn\":\"netease\",\"nameZh\":\"网易云音乐\",\"value\":\"https://music.163.com/#/user/home?id=\",\"type\":2},{\"id\":19,\"nameEn\":\"email\",\"nameZh\":\"email\",\"value\":\"508506630@qq.com\",\"type\":2},{\"id\":20,\"nameEn\":\"favorite\",\"nameZh\":\"自定义\",\"value\":\"{\\\"title\\\":\\\"最喜欢的动漫 📺\\\",\\\"content\\\":\\\"异度侵入、春物语、NO GAME NO LIFE、实力至上主义的教室、辉夜大小姐、青春猪头少年不会梦到兔女郎学姐、路人女主、Re0、魔禁、超炮、俺妹、在下坂本、散华礼弥、OVERLORD、慎勇、人渣的本愿、白色相簿2、死亡笔记、DARLING in the FRANXX、鬼灭之刃\\\"}\",\"type\":2},{\"id\":21,\"nameEn\":\"favorite\",\"nameZh\":\"自定义\",\"value\":\"{\\\"title\\\":\\\"最','更新站点配置信息','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',39,'2023-05-14 13:52:26','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(5,'Admin','/admin/about','PUT','{\"map\":{\"title\":\"关于帅气的 Naccl\",\"musicId\":\"423015580\",\"content\":\"哈哈哈\",\"commentEnabled\":\"true\"}}','修改关于我页面','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',12,'2023-05-14 13:53:17','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(6,'Admin','/admin/job/run','POST','{\"jobId\":1}','立即执行定时任务','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',6,'2023-05-14 13:53:49','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(7,'haoxx','/admin/blog','POST','{\"blog\":{\"id\":1,\"title\":\"终端美化记录\",\"firstPicture\":\"https://tenapi.cn/v2/acg\",\"content\":\"## 一、ubuntu安装zsh、powerlevel10k\\n\\n参考[csdn的教程](https://blog.51cto.com/sddai/3030120)：\\n\\n[ohmyzsh的github](https://github.com/ohmyzsh/ohmyzsh)\\n\\n[powerlevel10k的github](https://github.com/romkatv/powerlevel10k)\\n\\npowerline这个不需要安装（powerlevel10k就是基于powerline的）：\\n\\n[powerline的github](https://github.com/powerline/powerline)\\n\\n1、安装zsh\\n\\n```bash\\nsudo apt-get install zsh\\n```\\n2、安装oh-my-zsh\\n```bash\\n# 或者去仓库手动下载，然后运行install.sh\\nsh -c \\\"$(curl -fsSL https://raw.github.com/robbyrussell/oh-my-zsh/master/tools/install.sh)\\\"\\n```\\n3、安装自动跳转插件和语法高亮插件、语法历史记录插件\\n\\n说明：zsh插件的位置在`/root/.oh-my-zsh//plugins`目录下。\\n\\n```bash\\nsudo apt-get install autojump\\n# 配置教程：cat /usr/share/doc/autojump/README.Debian\\nvim .zshrc\\n#在最后一行加入，注意点后面是一个空格\\n. /usr/share/autojump/autojump.sh\\nsource ~/.zshrc\\n```\\n语法高亮：\\n```bash\\n> git clone https://github.com/zsh-users/zsh-syntax-highlighting.git\\n> echo \\\"source ${(q-)PWD}/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh\\\" >> ${ZDOTDIR:-$HOME}/.zshrc\\n> source ~/.zshrc\\n```\\nzsh-autosuggestions语法历史记录插件：\\n```bash\\n> git clone git://github.com/zsh-users/zsh-autosuggestions $ZSH_CUSTOM/plugins/zsh-autosuggestions\\n> plugins=(zsh-autosuggestions)\\n```\\n\\n4、安装powerlevel10k命令行显示主题：\\n\\n```bash\\n# 1） 安装Meslo字体\\n## 1.1）下载字体\\nhttps://github.com/ryanoasis/nerd-fonts/tree/master/patched-fonts/Meslo/M/Regular\\n## 1.2）安装字体\\n# 将*.ttf字体文件放在/usr/share/fonts/custom目录下，该目录是自己新建的，然后\\ncd /usr/share/fonts/agave\\nsudo mkfontscale # 生成核心字体信息\\nsudo mkfontdir # 生成字体文件夹\\nsudo fc-cache -fv # 刷新系统字体缓存\\n# 2）安装powerlevel10k\\n## 2.1）下载\\ngit clone --depth=1 https://gitee.com/romkatv/powerlevel10k.git ${ZSH_CUSTOM:-$HOME/.oh-my-zsh/custom}/themes/powerlevel10k\\n## 2.2）安装\\nSet ZSH_THEME=\\\"powerlevel10k/powerlevel10k\\\" in ~/.zshrc.\\n## 说明：或者手动从github上下载powerlebel10k，然后放在/root/.oh-my-zsh/custom/themes目录下，最后在.zshrc中设置主题即可\\n```\\n\\n### 1.1 powerlevel10k的配置\\n\\n见github仓库。  另外，您参考[CSDN的教程:powerlevel10k 颜色和图标的自','发布博客','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',37,'2023-05-14 14:00:14','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(8,'haoxx','/admin/siteSettings','POST','{\"map\":{\"settings\":[{\"id\":1,\"nameEn\":\"blogName\",\"nameZh\":\"博客名称\",\"value\":\"Haoxxl\'s Blog\",\"type\":1},{\"id\":2,\"nameEn\":\"webTitleSuffix\",\"nameZh\":\"网页标题后缀\",\"value\":\" - Haoxx\'s Blog\",\"type\":1},{\"id\":3,\"nameEn\":\"footerImgTitle\",\"nameZh\":\"页脚图片标题\",\"value\":\"手机看本站\",\"type\":1},{\"id\":4,\"nameEn\":\"footerImgUrl\",\"nameZh\":\"页脚图片路径\",\"value\":\"/img/qr.png\",\"type\":1},{\"id\":5,\"nameEn\":\"copyright\",\"nameZh\":\"Copyright\",\"value\":\"{\\\"title\\\":\\\"Copyright © 2022 - 2023\\\",\\\"siteName\\\":\\\"HAOXX\'S BLOG\\\"}\",\"type\":1},{\"id\":6,\"nameEn\":\"beian\",\"nameZh\":\"ICP备案号\",\"value\":\"渝ICP备2023001651号\",\"type\":1},{\"id\":7,\"nameEn\":\"reward\",\"nameZh\":\"赞赏码\",\"value\":\"/img/reward.jpg\",\"type\":1},{\"id\":8,\"nameEn\":\"commentAdminFlag\",\"nameZh\":\"博主评论标识\",\"value\":\"小鱼\",\"type\":1},{\"id\":9,\"nameEn\":\"playlistServer\",\"nameZh\":\"播放器平台\",\"value\":\"netease\",\"type\":1},{\"id\":10,\"nameEn\":\"playlistId\",\"nameZh\":\"播放器歌单\",\"value\":\"3071528549\",\"type\":1},{\"id\":11,\"nameEn\":\"avatar\",\"nameZh\":\"头像\",\"value\":\"/img/blog_head_logo.gif\",\"type\":2},{\"id\":12,\"nameEn\":\"name\",\"nameZh\":\"昵称\",\"value\":\"浩XX\",\"type\":2},{\"id\":13,\"nameEn\":\"rollText\",\"nameZh\":\"滚动个签\",\"value\":\"\\\"云鹤当归天，天不迎我妙木仙；\\\",\\\"游龙当归海，海不迎我自来也。\\\"\",\"type\":2},{\"id\":14,\"nameEn\":\"github\",\"nameZh\":\"GitHub\",\"value\":\"https://github.com/XiaoYuer2022\",\"type\":2},{\"id\":15,\"nameEn\":\"telegram\",\"nameZh\":\"Telegram\",\"value\":\"https://t.me/NacclOfficial\",\"type\":2},{\"id\":16,\"nameEn\":\"qq\",\"nameZh\":\"QQ\",\"value\":\"http://sighttp.qq.com/authd?IDKEY=\",\"type\":2},{\"id\":17,\"nameEn\":\"bilibili\",\"nameZh\":\"bilibili\",\"value\":\"https://space.bilibili.com/\",\"type\":2},{\"id\":18,\"nameEn\":\"netease\",\"nameZh\":\"网易云音乐\",\"value\":\"https://music.163.com/#/user/home?id=\",\"type\":2},{\"id\":19,\"nameEn\":\"email\",\"nameZh\":\"email\",\"value\":\"508506630@qq.com\",\"type\":2},{\"id\":20,\"nameEn\":\"favorite\",\"nameZh\":\"自定义\",\"value\":\"{\\\"title\\\":\\\"最喜欢的动漫 📺\\\",\\\"content\\\":\\\"异度侵入、春物语、NO GAME NO LIFE、实力至上主义的教室、辉夜大小姐、青春猪头少年不会梦到兔女郎学姐、路人女主、Re0、魔禁、超炮、俺妹、在下坂本、散华礼弥、OVERLORD、慎勇、人渣的本愿、白色相簿2、死亡笔记、DARLING in the FRANXX、鬼灭之刃\\\"}\",\"type\":2},{\"id\":21,\"nameEn\":\"favorite\",\"nameZh\":\"自定义\",\"value\":\"{\\\"tit','更新站点配置信息','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',29,'2023-05-14 14:28:11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(9,'haoxx','/admin/siteSettings','POST','{\"map\":{\"settings\":[{\"id\":1,\"nameEn\":\"blogName\",\"nameZh\":\"博客名称\",\"value\":\"Haoxx\'s Blog\",\"type\":1},{\"id\":2,\"nameEn\":\"webTitleSuffix\",\"nameZh\":\"网页标题后缀\",\"value\":\" - Haoxx\'s Blog\",\"type\":1},{\"id\":3,\"nameEn\":\"footerImgTitle\",\"nameZh\":\"页脚图片标题\",\"value\":\"手机看本站\",\"type\":1},{\"id\":4,\"nameEn\":\"footerImgUrl\",\"nameZh\":\"页脚图片路径\",\"value\":\"/img/qr.png\",\"type\":1},{\"id\":5,\"nameEn\":\"copyright\",\"nameZh\":\"Copyright\",\"value\":\"{\\\"title\\\":\\\"Copyright © 2022 - 2023\\\",\\\"siteName\\\":\\\"HAOXX\'S BLOG\\\"}\",\"type\":1},{\"id\":6,\"nameEn\":\"beian\",\"nameZh\":\"ICP备案号\",\"value\":\"渝ICP备2023001651号\",\"type\":1},{\"id\":7,\"nameEn\":\"reward\",\"nameZh\":\"赞赏码\",\"value\":\"/img/reward.jpg\",\"type\":1},{\"id\":8,\"nameEn\":\"commentAdminFlag\",\"nameZh\":\"博主评论标识\",\"value\":\"小鱼\",\"type\":1},{\"id\":9,\"nameEn\":\"playlistServer\",\"nameZh\":\"播放器平台\",\"value\":\"netease\",\"type\":1},{\"id\":10,\"nameEn\":\"playlistId\",\"nameZh\":\"播放器歌单\",\"value\":\"3071528549\",\"type\":1},{\"id\":11,\"nameEn\":\"avatar\",\"nameZh\":\"头像\",\"value\":\"/img/blog_head_logo.gif\",\"type\":2},{\"id\":12,\"nameEn\":\"name\",\"nameZh\":\"昵称\",\"value\":\"浩XX\",\"type\":2},{\"id\":13,\"nameEn\":\"rollText\",\"nameZh\":\"滚动个签\",\"value\":\"\\\"云鹤当归天，天不迎我妙木仙；\\\",\\\"游龙当归海，海不迎我自来也。\\\"\",\"type\":2},{\"id\":14,\"nameEn\":\"github\",\"nameZh\":\"GitHub\",\"value\":\"https://github.com/XiaoYuer2022\",\"type\":2},{\"id\":15,\"nameEn\":\"telegram\",\"nameZh\":\"Telegram\",\"value\":\"https://t.me/NacclOfficial\",\"type\":2},{\"id\":16,\"nameEn\":\"qq\",\"nameZh\":\"QQ\",\"value\":\"http://sighttp.qq.com/authd?IDKEY=\",\"type\":2},{\"id\":17,\"nameEn\":\"bilibili\",\"nameZh\":\"bilibili\",\"value\":\"https://space.bilibili.com/\",\"type\":2},{\"id\":18,\"nameEn\":\"netease\",\"nameZh\":\"网易云音乐\",\"value\":\"https://music.163.com/#/user/home?id=\",\"type\":2},{\"id\":19,\"nameEn\":\"email\",\"nameZh\":\"email\",\"value\":\"508506630@qq.com\",\"type\":2},{\"id\":20,\"nameEn\":\"favorite\",\"nameZh\":\"自定义\",\"value\":\"{\\\"title\\\":\\\"最喜欢的动漫 📺\\\",\\\"content\\\":\\\"异度侵入、春物语、NO GAME NO LIFE、实力至上主义的教室、辉夜大小姐、青春猪头少年不会梦到兔女郎学姐、路人女主、Re0、魔禁、超炮、俺妹、在下坂本、散华礼弥、OVERLORD、慎勇、人渣的本愿、白色相簿2、死亡笔记、DARLING in the FRANXX、鬼灭之刃\\\"}\",\"type\":2},{\"id\":21,\"nameEn\":\"favorite\",\"nameZh\":\"自定义\",\"value\":\"{\\\"titl','更新站点配置信息','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',26,'2023-05-14 14:36:32','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68');
/*!40000 ALTER TABLE `operation_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule_job`
--

DROP TABLE IF EXISTS `schedule_job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schedule_job` (
  `job_id` bigint NOT NULL AUTO_INCREMENT COMMENT '任务id',
  `bean_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'spring bean名称',
  `method_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '方法名',
  `params` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '参数',
  `cron` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'cron表达式',
  `status` tinyint DEFAULT NULL COMMENT '任务状态',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '备注',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`job_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule_job`
--

LOCK TABLES `schedule_job` WRITE;
/*!40000 ALTER TABLE `schedule_job` DISABLE KEYS */;
INSERT INTO `schedule_job` VALUES (1,'redisSyncScheduleTask','syncBlogViewsToDatabase','','0 0 1 * * ?',1,'每天凌晨一点，从Redis将博客浏览量同步到数据库','2020-11-17 23:45:42'),(2,'visitorSyncScheduleTask','syncVisitInfoToDatabase','','0 0 0 * * ?',1,'清空当天Redis访客标识，记录当天的PV和UV，更新当天所有访客的PV和最后访问时间，更新城市新增访客UV数','2021-02-05 08:14:28');
/*!40000 ALTER TABLE `schedule_job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule_job_log`
--

DROP TABLE IF EXISTS `schedule_job_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schedule_job_log` (
  `log_id` bigint NOT NULL AUTO_INCREMENT COMMENT '任务日志id',
  `job_id` bigint NOT NULL COMMENT '任务id',
  `bean_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'spring bean名称',
  `method_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '方法名',
  `params` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '参数',
  `status` tinyint NOT NULL COMMENT '任务执行结果',
  `error` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT '异常信息',
  `times` int NOT NULL COMMENT '耗时（单位：毫秒）',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`log_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule_job_log`
--

LOCK TABLES `schedule_job_log` WRITE;
/*!40000 ALTER TABLE `schedule_job_log` DISABLE KEYS */;
INSERT INTO `schedule_job_log` VALUES (1,1,'redisSyncScheduleTask','syncBlogViewsToDatabase','',1,NULL,3,'2023-05-14 13:53:49');
/*!40000 ALTER TABLE `schedule_job_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_setting`
--

DROP TABLE IF EXISTS `site_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `site_setting` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name_en` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `name_zh` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `type` int DEFAULT NULL COMMENT '1基础设置，2页脚徽标，3资料卡，4友链信息',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_setting`
--

LOCK TABLES `site_setting` WRITE;
/*!40000 ALTER TABLE `site_setting` DISABLE KEYS */;
INSERT INTO `site_setting` VALUES (1,'blogName','博客名称','Haoxx\'s Blog',1),(2,'webTitleSuffix','网页标题后缀',' - Haoxx\'s Blog',1),(3,'footerImgTitle','页脚图片标题','手机看本站',1),(4,'footerImgUrl','页脚图片路径','/img/qr.png',1),(5,'copyright','Copyright','{\"title\":\"Copyright © 2022 - 2023\",\"siteName\":\"HAOXX\'S BLOG\"}',1),(6,'beian','ICP备案号','渝ICP备2023001651号',1),(7,'reward','赞赏码','/img/reward.jpg',1),(8,'commentAdminFlag','博主评论标识','小鱼',1),(9,'playlistServer','播放器平台','netease',1),(10,'playlistId','播放器歌单','3071528549',1),(11,'avatar','头像','/img/blog_head_logo.gif',2),(12,'name','昵称','浩XX',2),(13,'rollText','滚动个签','\"云鹤当归天，天不迎我妙木仙；\",\"游龙当归海，海不迎我自来也。\"',2),(14,'github','GitHub','https://github.com/XiaoYuer2022',2),(15,'telegram','Telegram','https://t.me/NacclOfficial',2),(16,'qq','QQ','http://sighttp.qq.com/authd?IDKEY=',2),(17,'bilibili','bilibili','https://space.bilibili.com/',2),(18,'netease','网易云音乐','https://music.163.com/#/user/home?id=',2),(19,'email','email','508506630@qq.com',2),(20,'favorite','自定义','{\"title\":\"最喜欢的动漫 📺\",\"content\":\"异度侵入、春物语、NO GAME NO LIFE、实力至上主义的教室、辉夜大小姐、青春猪头少年不会梦到兔女郎学姐、路人女主、Re0、魔禁、超炮、俺妹、在下坂本、散华礼弥、OVERLORD、慎勇、人渣的本愿、白色相簿2、死亡笔记、DARLING in the FRANXX、鬼灭之刃\"}',2),(21,'favorite','自定义','{\"title\":\"最喜欢我的女孩子们 🤤\",\"content\":\"芙兰达、土间埋、食蜂操祈、佐天泪爷、樱岛麻衣、桐崎千棘、02、亚丝娜、高坂桐乃、五更琉璃、安乐冈花火、一色彩羽、英梨梨、珈百璃、时崎狂三、可儿那由多、和泉纱雾、早坂爱\"}',2),(22,'favorite','自定义','{\"title\":\"最喜欢玩的游戏 🎮\",\"content\":\"Stellaris、巫师、GTA、荒野大镖客、刺客信条、魔兽争霸、LOL、PUBG\"}',2),(23,'badge','徽标','{\"title\":\"本博客已开源于 GitHub\",\"url\":\"https://github.com/Naccl/NBlog\",\"subject\":\"NBlog\",\"value\":\"Open Source\",\"color\":\"brightgreen\"}',3),(24,'badge','徽标','{\"title\":\"由 Spring Boot 强力驱动\",\"url\":\"https://spring.io/projects/spring-boot/\",\"subject\":\"Powered\",\"value\":\"Spring Boot\",\"color\":\"blue\"}',3),(25,'badge','徽标','{\"title\":\"Vue.js 客户端渲染\",\"url\":\"https://cn.vuejs.org/\",\"subject\":\"SPA\",\"value\":\"Vue.js\",\"color\":\"brightgreen\"}',3),(26,'badge','徽标','{\"title\":\"UI 框架 Semantic-UI\",\"url\":\"https://semantic-ui.com/\",\"subject\":\"UI\",\"value\":\"Semantic-UI\",\"color\":\"semantic-ui\"}',3),(27,'badge','徽标','{\"title\":\"阿里云提供服务器及域名相关服务\",\"url\":\"https://www.aliyun.com/\",\"subject\":\"VPS & DNS\",\"value\":\"Aliyun\",\"color\":\"blueviolet\"}',3),(28,'badge','徽标','{\"title\":\"静态资源托管于 GitHub\",\"url\":\"https://github.com/\",\"subject\":\"OSS\",\"value\":\"GitHub\",\"color\":\"github\"}',3),(29,'badge','徽标','{\"title\":\"jsDelivr 加速静态资源\",\"url\":\"https://www.jsdelivr.com/\",\"subject\":\"CDN\",\"value\":\"jsDelivr\",\"color\":\"orange\"}',3),(30,'badge','徽标','{\"color\":\"lightgray\",\"subject\":\"CC\",\"title\":\"本站点采用 CC BY 4.0 国际许可协议进行许可\",\"url\":\"https://creativecommons.org/licenses/by/4.0/\",\"value\":\"BY 4.0\"}',3),(31,'friendContent','友链页面信息','随机排序，不分先后。欢迎交换友链~(￣▽￣)~*\n\n* 昵称：Naccl\n* 一句话：游龙当归海，海不迎我自来也。\n* 网址：[https://naccl.top](https://naccl.top)\n* 头像URL：[https://naccl.top/img/avatar.jpg](https://naccl.top/img/avatar.jpg)\n\n仅凭个人喜好添加友链，请在收到我的回复邮件后再于贵站添加本站链接。原则上已添加的友链不会删除，如果你发现自己被移除了，恕不另行通知，只需和我一样做就好。\n\n',4),(32,'friendCommentEnabled','友链页面评论开关','1',4);
/*!40000 ALTER TABLE `site_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag`
--

DROP TABLE IF EXISTS `tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tag` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `tag_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `color` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '标签颜色(可选)',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag`
--

LOCK TABLES `tag` WRITE;
/*!40000 ALTER TABLE `tag` DISABLE KEYS */;
INSERT INTO `tag` VALUES (1,'娱乐',NULL);
/*!40000 ALTER TABLE `tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户名',
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '密码',
  `nickname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '昵称',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '头像地址',
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '邮箱',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `update_time` datetime NOT NULL COMMENT '更新时间',
  `role` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '角色访问权限',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'haoxx','$2a$10$SdhO78oBtef5Rh5wZpCRieIlFn78tNOeXliacYywrD0CDoLyzZpyO','Admin','/img/avatar.jpg','508506630@qq.com','2020-09-21 16:47:18','2023-05-14 13:54:18','ROLE_admin');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visit_log`
--

DROP TABLE IF EXISTS `visit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `visit_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '访客标识码',
  `uri` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '请求接口',
  `method` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '请求方式',
  `param` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '请求参数',
  `behavior` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '访问行为',
  `content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '访问内容',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '备注',
  `ip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'ip',
  `ip_source` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'ip来源',
  `os` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '操作系统',
  `browser` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '浏览器',
  `times` int NOT NULL COMMENT '请求耗时（毫秒）',
  `create_time` datetime NOT NULL COMMENT '访问时间',
  `user_agent` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'user-agent用户代理',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visit_log`
--

LOCK TABLES `visit_log` WRITE;
/*!40000 ALTER TABLE `visit_log` DISABLE KEYS */;
INSERT INTO `visit_log` VALUES (1,'5acb4578-6630-379c-80cb-25ad67684318','/blogs','GET','{\"pageNum\":1}','访问页面','首页','第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',81,'2023-05-14 11:18:13','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(2,'5acb4578-6630-379c-80cb-25ad67684318','/archives','GET','{}','访问页面','归档','','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',11,'2023-05-14 11:18:16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(3,'5acb4578-6630-379c-80cb-25ad67684318','/moments','GET','{\"pageNum\":1}','访问页面','动态','第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',7,'2023-05-14 11:18:19','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(4,'5acb4578-6630-379c-80cb-25ad67684318','/friends','GET','{}','访问页面','友链','','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',72,'2023-05-14 11:18:21','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(5,'5acb4578-6630-379c-80cb-25ad67684318','/about','GET','{}','访问页面','关于我','','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',10,'2023-05-14 11:18:23','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(6,'5acb4578-6630-379c-80cb-25ad67684318','/blogs','GET','{\"pageNum\":1}','访问页面','首页','第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',6,'2023-05-14 11:18:45','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(7,'5acb4578-6630-379c-80cb-25ad67684318','/archives','GET','{}','访问页面','归档','','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',2,'2023-05-14 11:18:47','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(8,'5acb4578-6630-379c-80cb-25ad67684318','/blogs','GET','{\"pageNum\":1}','访问页面','首页','第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',19,'2023-05-14 13:48:05','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(9,'5acb4578-6630-379c-80cb-25ad67684318','/archives','GET','{}','访问页面','归档','','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',4,'2023-05-14 13:48:24','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(10,'5acb4578-6630-379c-80cb-25ad67684318','/moments','GET','{\"pageNum\":1}','访问页面','动态','第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',37,'2023-05-14 13:48:26','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(11,'5acb4578-6630-379c-80cb-25ad67684318','/friends','GET','{}','访问页面','友链','','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',8,'2023-05-14 13:48:27','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(12,'5acb4578-6630-379c-80cb-25ad67684318','/about','GET','{}','访问页面','关于我','','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',5,'2023-05-14 13:48:28','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(13,'5acb4578-6630-379c-80cb-25ad67684318','/blogs','GET','{\"pageNum\":1}','访问页面','首页','第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',2,'2023-05-14 13:48:30','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(14,'5acb4578-6630-379c-80cb-25ad67684318','/blogs','GET','{\"pageNum\":1}','访问页面','首页','第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',6,'2023-05-14 13:48:41','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(15,'5acb4578-6630-379c-80cb-25ad67684318','/friends','GET','{}','访问页面','友链','','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',4,'2023-05-14 13:48:53','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(16,'5acb4578-6630-379c-80cb-25ad67684318','/about','GET','{}','访问页面','关于我','','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',1,'2023-05-14 13:48:56','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(17,'5acb4578-6630-379c-80cb-25ad67684318','/friends','GET','{}','访问页面','友链','','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',3,'2023-05-14 13:52:55','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(18,'5acb4578-6630-379c-80cb-25ad67684318','/moments','GET','{\"pageNum\":1}','访问页面','动态','第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',40,'2023-05-14 13:52:55','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(19,'5acb4578-6630-379c-80cb-25ad67684318','/archives','GET','{}','访问页面','归档','','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',2,'2023-05-14 13:52:57','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(20,'5acb4578-6630-379c-80cb-25ad67684318','/blogs','GET','{\"pageNum\":1}','访问页面','首页','第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',2,'2023-05-14 13:53:02','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(21,'5acb4578-6630-379c-80cb-25ad67684318','/archives','GET','{}','访问页面','归档','','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',2,'2023-05-14 13:53:03','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(22,'5acb4578-6630-379c-80cb-25ad67684318','/moments','GET','{\"pageNum\":1}','访问页面','动态','第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',4,'2023-05-14 13:53:03','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(23,'5acb4578-6630-379c-80cb-25ad67684318','/friends','GET','{}','访问页面','友链','','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',2,'2023-05-14 13:53:04','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(24,'5acb4578-6630-379c-80cb-25ad67684318','/about','GET','{}','访问页面','关于我','','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',1,'2023-05-14 13:53:06','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(25,'5acb4578-6630-379c-80cb-25ad67684318','/about','GET','{}','访问页面','关于我','','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',7,'2023-05-14 13:53:21','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(26,'5acb4578-6630-379c-80cb-25ad67684318','/about','GET','{}','访问页面','关于我','','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',2,'2023-05-14 14:00:18','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(27,'5acb4578-6630-379c-80cb-25ad67684318','/blogs','GET','{\"pageNum\":1}','访问页面','首页','第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',11,'2023-05-14 14:00:21','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(28,'5acb4578-6630-379c-80cb-25ad67684318','/blog','GET','{\"id\":1}','查看博客','终端美化记录','文章标题：终端美化记录','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',15,'2023-05-14 14:00:42','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(29,'5acb4578-6630-379c-80cb-25ad67684318','/about','GET','{}','访问页面','关于我','','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',2,'2023-05-14 14:01:40','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(30,'5acb4578-6630-379c-80cb-25ad67684318','/searchBlog','GET','{\"query\":\"Ubuntu\"}','搜索博客','Ubuntu','搜索内容：Ubuntu','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',2,'2023-05-14 14:02:34','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(31,'5acb4578-6630-379c-80cb-25ad67684318','/blog','GET','{\"id\":1}','查看博客','终端美化记录','文章标题：终端美化记录','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',7,'2023-05-14 14:02:36','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(32,'5acb4578-6630-379c-80cb-25ad67684318','/blogs','GET','{\"pageNum\":1}','访问页面','首页','第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',5,'2023-05-14 14:17:21','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(33,'5acb4578-6630-379c-80cb-25ad67684318','/blogs','GET','{\"pageNum\":1}','访问页面','首页','第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',4,'2023-05-14 14:24:31','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(34,'5acb4578-6630-379c-80cb-25ad67684318','/about','GET','{}','访问页面','关于我','','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',3,'2023-05-14 14:25:10','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(35,'5acb4578-6630-379c-80cb-25ad67684318','/friends','GET','{}','访问页面','友链','','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',3,'2023-05-14 14:25:19','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(36,'5acb4578-6630-379c-80cb-25ad67684318','/moments','GET','{\"pageNum\":1}','访问页面','动态','第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',5,'2023-05-14 14:25:22','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(37,'5acb4578-6630-379c-80cb-25ad67684318','/archives','GET','{}','访问页面','归档','','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',8,'2023-05-14 14:25:23','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(38,'5acb4578-6630-379c-80cb-25ad67684318','/category','GET','{\"categoryName\":\"系统美化记录\",\"pageNum\":1}','查看分类','系统美化记录','分类名称：系统美化记录，第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',9,'2023-05-14 14:25:28','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(39,'5acb4578-6630-379c-80cb-25ad67684318','/blogs','GET','{\"pageNum\":1}','访问页面','首页','第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',6,'2023-05-14 14:25:30','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(40,'5acb4578-6630-379c-80cb-25ad67684318','/blogs','GET','{\"pageNum\":1}','访问页面','首页','第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',4,'2023-05-14 14:25:44','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(41,'5acb4578-6630-379c-80cb-25ad67684318','/friends','GET','{}','访问页面','友链','','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',3,'2023-05-14 14:26:00','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(42,'5acb4578-6630-379c-80cb-25ad67684318','/moments','GET','{\"pageNum\":1}','访问页面','动态','第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',4,'2023-05-14 14:26:01','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(43,'5acb4578-6630-379c-80cb-25ad67684318','/archives','GET','{}','访问页面','归档','','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',1,'2023-05-14 14:26:01','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(44,'5acb4578-6630-379c-80cb-25ad67684318','/blogs','GET','{\"pageNum\":1}','访问页面','首页','第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',4,'2023-05-14 14:26:03','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(45,'5acb4578-6630-379c-80cb-25ad67684318','/blogs','GET','{\"pageNum\":1}','访问页面','首页','第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',5,'2023-05-14 14:28:14','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(46,'5acb4578-6630-379c-80cb-25ad67684318','/blogs','GET','{\"pageNum\":1}','访问页面','首页','第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',5,'2023-05-14 14:30:32','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(47,'5acb4578-6630-379c-80cb-25ad67684318','/blogs','GET','{\"pageNum\":1}','访问页面','首页','第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',5,'2023-05-14 14:32:10','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(48,'5acb4578-6630-379c-80cb-25ad67684318','/blogs','GET','{\"pageNum\":1}','访问页面','首页','第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',6,'2023-05-14 14:32:54','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(49,'5acb4578-6630-379c-80cb-25ad67684318','/blogs','GET','{\"pageNum\":1}','访问页面','首页','第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',7,'2023-05-14 14:33:15','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(50,'5acb4578-6630-379c-80cb-25ad67684318','/blogs','GET','{\"pageNum\":1}','访问页面','首页','第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',6,'2023-05-14 14:33:39','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(51,'5acb4578-6630-379c-80cb-25ad67684318','/blogs','GET','{\"pageNum\":1}','访问页面','首页','第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',8,'2023-05-14 14:33:41','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(52,'5acb4578-6630-379c-80cb-25ad67684318','/blogs','GET','{\"pageNum\":1}','访问页面','首页','第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',7,'2023-05-14 14:35:13','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(53,'5acb4578-6630-379c-80cb-25ad67684318','/blogs','GET','{\"pageNum\":1}','访问页面','首页','第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',6,'2023-05-14 14:35:22','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(54,'5acb4578-6630-379c-80cb-25ad67684318','/blogs','GET','{\"pageNum\":1}','访问页面','首页','第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',5,'2023-05-14 14:35:40','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(55,'5acb4578-6630-379c-80cb-25ad67684318','/blogs','GET','{\"pageNum\":1}','访问页面','首页','第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',5,'2023-05-14 14:39:59','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(56,'5acb4578-6630-379c-80cb-25ad67684318','/about','GET','{}','访问页面','关于我','','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',2,'2023-05-14 14:43:28','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(57,'5acb4578-6630-379c-80cb-25ad67684318','/about','GET','{}','访问页面','关于我','','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',2,'2023-05-14 14:44:19','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(58,'5acb4578-6630-379c-80cb-25ad67684318','/about','GET','{}','访问页面','关于我','','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',3,'2023-05-14 14:45:05','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(59,'5acb4578-6630-379c-80cb-25ad67684318','/blogs','GET','{\"pageNum\":1}','访问页面','首页','第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',3,'2023-05-14 14:46:11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(60,'5acb4578-6630-379c-80cb-25ad67684318','/about','GET','{}','访问页面','关于我','','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',2,'2023-05-14 14:47:08','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(61,'5acb4578-6630-379c-80cb-25ad67684318','/friends','GET','{}','访问页面','友链','','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',4,'2023-05-14 14:47:11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(62,'5acb4578-6630-379c-80cb-25ad67684318','/moments','GET','{\"pageNum\":1}','访问页面','动态','第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',3,'2023-05-14 14:47:11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(63,'5acb4578-6630-379c-80cb-25ad67684318','/archives','GET','{}','访问页面','归档','','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',1,'2023-05-14 14:47:12','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(64,'5acb4578-6630-379c-80cb-25ad67684318','/category','GET','{\"categoryName\":\"系统美化记录\",\"pageNum\":1}','查看分类','系统美化记录','分类名称：系统美化记录，第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',6,'2023-05-14 14:47:14','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(65,'5acb4578-6630-379c-80cb-25ad67684318','/blogs','GET','{\"pageNum\":1}','访问页面','首页','第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',3,'2023-05-14 14:47:15','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(66,'5acb4578-6630-379c-80cb-25ad67684318','/moments','GET','{\"pageNum\":1}','访问页面','动态','第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',4,'2023-05-14 14:47:16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(67,'5acb4578-6630-379c-80cb-25ad67684318','/archives','GET','{}','访问页面','归档','','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',1,'2023-05-14 14:47:18','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(68,'5acb4578-6630-379c-80cb-25ad67684318','/friends','GET','{}','访问页面','友链','','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',3,'2023-05-14 14:47:21','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(69,'5acb4578-6630-379c-80cb-25ad67684318','/about','GET','{}','访问页面','关于我','','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',1,'2023-05-14 14:47:23','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(70,'5acb4578-6630-379c-80cb-25ad67684318','/blogs','GET','{\"pageNum\":1}','访问页面','首页','第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',3,'2023-05-14 14:48:11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(71,'5acb4578-6630-379c-80cb-25ad67684318','/blogs','GET','{\"pageNum\":1}','访问页面','首页','第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',67,'2023-05-14 16:04:26','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(72,'5acb4578-6630-379c-80cb-25ad67684318','/archives','GET','{}','访问页面','归档','','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',32,'2023-05-14 16:04:25','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68'),(73,'5acb4578-6630-379c-80cb-25ad67684318','/blogs','GET','{\"pageNum\":1}','访问页面','首页','第1页','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112',7,'2023-05-14 16:04:32','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68');
/*!40000 ALTER TABLE `visit_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visit_record`
--

DROP TABLE IF EXISTS `visit_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `visit_record` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `pv` int NOT NULL COMMENT '访问量',
  `uv` int NOT NULL COMMENT '独立用户',
  `date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '日期"02-23"',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visit_record`
--

LOCK TABLES `visit_record` WRITE;
/*!40000 ALTER TABLE `visit_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `visit_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visitor`
--

DROP TABLE IF EXISTS `visitor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `visitor` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '访客标识码',
  `ip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'ip',
  `ip_source` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'ip来源',
  `os` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '操作系统',
  `browser` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '浏览器',
  `create_time` datetime NOT NULL COMMENT '首次访问时间',
  `last_time` datetime NOT NULL COMMENT '最后访问时间',
  `pv` int DEFAULT NULL COMMENT '访问页数统计',
  `user_agent` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'user-agent用户代理',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `idx_uuid` (`uuid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visitor`
--

LOCK TABLES `visitor` WRITE;
/*!40000 ALTER TABLE `visitor` DISABLE KEYS */;
INSERT INTO `visitor` VALUES (1,'5acb4578-6630-379c-80cb-25ad67684318','10.16.11.187','内网IP|内网IP','Windows >=10','Edge 112','2023-05-14 11:18:13','2023-05-14 11:18:13',0,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68');
/*!40000 ALTER TABLE `visitor` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-14 20:06:11
